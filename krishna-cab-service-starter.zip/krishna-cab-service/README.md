# Krishna Cab Service — booking website starter

A responsive React + Vite travel booking website for Krishna Cab Service. Includes a customer-facing home/services/destinations/booking flow and a demo admin dashboard. Supabase integration is optional until configured.

## Included
- Responsive modern landing page and service/destination pages
- Booking enquiry form with required-field validation
- Demo booking storage in the current browser when Supabase is not configured
- Supabase insert/load/update integration scaffold
- Admin dashboard UI: stats, search, status filters, booking detail modal
- Supabase starter SQL schema in `supabase/schema.sql`

## Run locally
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Run `npm run dev` and open the local URL shown by Vite.
4. Demo admin password: `KCS-demo-2026`.

## Connect Supabase
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local`.
4. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (publishable/anon key only).
5. Restart Vite.

**Production security note:** the admin login is demo-only and must not be used to protect real booking data. Before launch, implement Supabase Auth, an admin role, and RLS policies that allow only authorized admins to read/update/delete bookings. Do not enable public SELECT/UPDATE/DELETE policies. Keep service-role keys server-side only. Until that work is complete, the connected public form can submit booking requests but the browser dashboard will not be able to read or update those rows under the safe starter RLS policy.

## GitHub
Create a new repository, then from this folder:
```bash
git init
git add .
git commit -m "Initial Krishna Cab Service booking website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Vercel
1. Import the GitHub repository in Vercel.
2. Framework preset: Vite (usually auto-detected).
3. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Project Settings → Environment Variables.
4. Deploy. Redeploy after changing environment variables.

## Customize before launch
- Replace the demo admin flow with Supabase Auth + role-based access.
- Verify phone and WhatsApp numbers, service list, business address, and pricing.
- Add privacy policy, terms, cancellation policy, and appropriate consent text.
- The hero currently uses a remote Unsplash image; replace with your own licensed image if desired.
